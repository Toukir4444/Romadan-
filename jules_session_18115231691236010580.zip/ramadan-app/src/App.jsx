import React, { useState } from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Planner from './components/Planner';
import Duas from './components/Duas';
import { Home, CheckSquare, BookOpen } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('home');

  return (
    <div className="min-h-screen bg-slate-50 font-sans pb-20">
      <Header />
      
      <main className="container mx-auto max-w-md">
        {activeTab === 'home' && <Dashboard />}
        {activeTab === 'planner' && <Planner />}
        {activeTab === 'duas' && <Duas />}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-[0_-1px_3px_rgba(0,0,0,0.05)] z-50">
        <div className="container mx-auto max-w-md flex justify-around py-3 px-2">
            <button 
                onClick={() => setActiveTab('home')}
                className={`flex flex-col items-center flex-1 rounded-lg transition-colors ${activeTab === 'home' ? 'text-emerald-600' : 'text-slate-400 hover:text-emerald-500'}`}
            >
                <Home className="w-6 h-6" strokeWidth={activeTab === 'home' ? 2.5 : 2} />
                <span className={`text-xs mt-1 ${activeTab === 'home' ? 'font-semibold' : 'font-medium'}`}>হোম</span>
            </button>
            <button 
                onClick={() => setActiveTab('planner')}
                className={`flex flex-col items-center flex-1 rounded-lg transition-colors ${activeTab === 'planner' ? 'text-emerald-600' : 'text-slate-400 hover:text-emerald-500'}`}
            >
                <CheckSquare className="w-6 h-6" strokeWidth={activeTab === 'planner' ? 2.5 : 2} />
                <span className={`text-xs mt-1 ${activeTab === 'planner' ? 'font-semibold' : 'font-medium'}`}>ইবাদত</span>
            </button>
            <button 
                onClick={() => setActiveTab('duas')}
                className={`flex flex-col items-center flex-1 rounded-lg transition-colors ${activeTab === 'duas' ? 'text-emerald-600' : 'text-slate-400 hover:text-emerald-500'}`}
            >
                <BookOpen className="w-6 h-6" strokeWidth={activeTab === 'duas' ? 2.5 : 2} />
                <span className={`text-xs mt-1 ${activeTab === 'duas' ? 'font-semibold' : 'font-medium'}`}>দোয়া</span>
            </button>
        </div>
      </nav>
    </div>
  );
}

export default App;
