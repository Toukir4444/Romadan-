import { Coordinates, CalculationMethod, PrayerTimes, Madhab } from 'adhan';

const DHAKA_LAT = 23.8103;
const DHAKA_LNG = 90.4125;

export const PRAYER_NAMES_BN = {
  fajr: 'ফজর',
  sunrise: 'সূর্যোদয়',
  dhuhr: 'জোহর',
  asr: 'আছর',
  maghrib: 'মাগরিব',
  isha: 'ইশা',
  sehri: 'সেহরি শেষ',
  iftar: 'ইফতার',
};

const toBengaliNumerals = (str) => {
  const bengaliNumerals = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/\d/g, (d) => bengaliNumerals[d]);
};

export const getPrayerTimes = () => {
  const coordinates = new Coordinates(DHAKA_LAT, DHAKA_LNG);
  
  // University of Islamic Sciences, Karachi
  const params = CalculationMethod.Karachi();
  params.madhab = Madhab.Hanafi; 

  // Get current date in Dhaka to ensure we calculate for the correct day
  const now = new Date();
  const dhakaDateString = now.toLocaleString("en-US", { timeZone: "Asia/Dhaka" });
  const dhakaDate = new Date(dhakaDateString); // This creates a date object with Dhaka's YMD/Time but in local (UTC) zone effectively

  const prayerTimes = new PrayerTimes(coordinates, dhakaDate, params);

  const formatTime = (time) => {
    return new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Dhaka',
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
    }).format(time);
  };

  const times = {
    sehri: formatTime(prayerTimes.fajr), // Sehri ends at Fajr start
    fajr: formatTime(prayerTimes.fajr),
    sunrise: formatTime(prayerTimes.sunrise),
    dhuhr: formatTime(prayerTimes.dhuhr),
    asr: formatTime(prayerTimes.asr),
    maghrib: formatTime(prayerTimes.maghrib), // Iftar starts at Maghrib
    iftar: formatTime(prayerTimes.maghrib),
    isha: formatTime(prayerTimes.isha),
  };
  
  const timesBn = {};
  for (const [key, value] of Object.entries(times)) {
      timesBn[key] = toBengaliNumerals(value)
        .replace('AM', 'am')
        .replace('PM', 'pm');
  }

  return {
    raw: prayerTimes, // Note: these are Date objects. If used on client, need to format carefully.
    formatted: times,
    formattedBn: timesBn,
    date: dhakaDate
  };
};

export const getNextPrayer = (currentPrayerTimes) => {
    const next = currentPrayerTimes.nextPrayer();
    // nextPrayer() uses the time of the prayerTimes object vs now?
    // Actually nextPrayer(date) uses the passed date or now.
    // We should check adhan docs or source. 
    // Usually it compares current time with prayer times.
    // Since we want to compare with "Now in Dhaka", we might need to be careful.
    // But `nextPrayer()` typically uses `new Date()` internally if not passed.
    
    // Ideally we pass `new Date()` which is absolute time (UTC).
    // The prayer times in `currentPrayerTimes` are also absolute times (UTC).
    // So `nextPrayer()` should work fine regardless of timezone as long as system clock is correct.

    if (next === 'none') {
        return { name: 'fajr', time: null, isTomorrow: true };
    }
    
    return { name: next, time: currentPrayerTimes[next], isTomorrow: false };
}
