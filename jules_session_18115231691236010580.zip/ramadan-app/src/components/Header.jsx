import React from 'react';
import { MoonStar } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-emerald-600 text-white p-4 shadow-md sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MoonStar className="w-8 h-8" />
          <h1 className="text-2xl font-bold">রমজান প্ল্যানার</h1>
        </div>
      </div>
    </header>
  );
};

export default Header;
