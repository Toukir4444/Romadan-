import React, { useState, useEffect } from 'react';
import { CheckCircle2, Circle } from 'lucide-react';

const TASKS = [
  { id: 'fajr', label: 'ফজর' },
  { id: 'dhuhr', label: 'জোহর' },
  { id: 'asr', label: 'আছর' },
  { id: 'maghrib', label: 'মাগরিব' },
  { id: 'isha', label: 'ইশা' },
  { id: 'taraweeh', label: 'তারাবিহ' },
  { id: 'quran', label: 'কুরআন তিলাওয়াত' },
  { id: 'dua', label: 'দুয়া ও ইস্তেগফার' },
  { id: 'charity', label: 'দান-সদকা' },
];

const Planner = () => {
  const [completed, setCompleted] = useState({});

  useEffect(() => {
    const today = new Date().toDateString();
    const stored = localStorage.getItem('ramadan-planner');
    
    if (stored) {
      const data = JSON.parse(stored);
      if (data.date === today) {
        setCompleted(data.tasks);
      } else {
        // New day, clear tasks but update date in storage implicitly on next save
        // Or just don't setCompleted, so it stays empty.
      }
    }
  }, []);

  const toggleTask = (id) => {
    const newState = { ...completed, [id]: !completed[id] };
    setCompleted(newState);
    
    localStorage.setItem('ramadan-planner', JSON.stringify({
      date: new Date().toDateString(),
      tasks: newState
    }));
  };

  const progress = Math.round((Object.values(completed).filter(Boolean).length / TASKS.length) * 100);

  return (
    <div className="p-4 space-y-6 animate-fade-in">
      <div className="bg-emerald-600 text-white rounded-2xl p-6 shadow-lg relative overflow-hidden">
        <h2 className="text-xl font-bold mb-2">আজকের ইবাদত</h2>
        <div className="flex items-end justify-between">
            <span className="text-emerald-100 text-sm">অগ্রগতি</span>
            <span className="text-3xl font-bold">{progress}%</span>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-emerald-800/30 h-2 rounded-full mt-2 overflow-hidden">
            <div 
                className="bg-white h-full transition-all duration-500 ease-out" 
                style={{ width: `${progress}%` }}
            />
        </div>
      </div>

      <div className="space-y-3">
        {TASKS.map(task => (
            <button
                key={task.id}
                onClick={() => toggleTask(task.id)}
                className={`w-full flex items-center justify-between p-4 rounded-xl border transition-all ${
                    completed[task.id] 
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                    : 'bg-white border-slate-100 text-slate-600 hover:border-emerald-100'
                }`}
            >
                <span className="font-medium text-lg">{task.label}</span>
                {completed[task.id] ? (
                    <CheckCircle2 className="text-emerald-500 w-6 h-6" />
                ) : (
                    <Circle className="text-slate-300 w-6 h-6" />
                )}
            </button>
        ))}
      </div>
    </div>
  );
};

export default Planner;
