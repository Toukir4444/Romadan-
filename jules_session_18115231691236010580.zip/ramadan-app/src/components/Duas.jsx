import React from 'react';

const DUAS = [
  {
    title: 'রোজার নিয়ত (সেহরি)',
    arabic: 'نَوَيْتُ اَنْ اُصُوْمَ غَدًا مِّنْ شَهْرِ رَمَضَانَ الْمُبَارَكِ فَرْضًا لَكَ يَا اللهُ فَتَقَبَّل مني إِنَّكَ أَنْتَ السَّمِيعُ الْعَلِيم',
    bangla: 'হে আল্লাহ! আমি আগামীকাল পবিত্র রমজানের তোমার পক্ষ থেকে নির্ধারিত ফরজ রোজা রাখার ইচ্ছা পোষণ (নিয়্যত) করলাম। অতএব তুমি আমার পক্ষ থেকে (আমার রোজা তথা পানাহার থেকে বিরত থাকাকে) কবুল কর, নিশ্চয়ই তুমি সর্বশ্রোতা ও সর্বজ্ঞানী।',
    pronunciation: 'নাওয়াইতু আন আছুমা গাদাম মিন শাহরি রমজানাল মুবারাকি ফারদাল্লাকা, ইয়া আল্লাহু ফাতাকাব্বাল মিন্নি ইন্নাকা আনতাস সামিউল আলিম।'
  },
  {
    title: 'ইফতারের দোয়া',
    arabic: 'اللَّهُمَّ لَكَ صُمْتُ وَعَلَى رِزْقِكَ أَفْطَرْتُ',
    bangla: 'হে আল্লাহ! আমি তোমারই সন্তুষ্টির জন্য রোজা রেখেছি এবং তোমারই দেয়া রিজিকের মাধ্যমে ইফতার করছি।',
    pronunciation: 'আল্লাহুম্মা লাকা ছুমতু ওয়া আলা রিযক্বিকা আফত্বারতু।'
  },
  {
      title: 'প্রথম দশ দিনের দোয়া (রহমত)',
      arabic: 'رَبِّ اغْفِرْ وَارْحَمْ وَأَنْتَ خَيْرُ الرَّاحِمِينَ',
      bangla: 'হে আমার প্রতিপালক! আমাকে ক্ষমা করুন ও দয়া করুন, আপনিই তো সর্বশ্রেষ্ঠ দয়ালু।',
      pronunciation: 'রাব্বিগফির ওয়ারহাম ওয়া আনতা খাইরুর রাহিমিন।'
  },
  {
      title: 'দ্বিতীয় দশ দিনের দোয়া (মাগফিরাত)',
      arabic: 'أَسْتَغْفِرُ اللهَ رَبِّي مِنْ كُلِّ ذَنْبٍ وَأَتُوبُ إِلَيْهِ',
      bangla: 'আমি আল্লাহর কাছে ক্ষমা প্রার্থনা করছি এবং তাঁরই দিকে ফিরে আসছি।',
      pronunciation: 'আস্তাগফিরুল্লাহ রাব্বি মিন কুল্লি জাম্বিন ওয়া আতুবু ইলাইহি।'
  },
  {
      title: 'তৃতীয় দশ দিনের দোয়া (নাজাত)',
      arabic: 'اللَّهُمَّ أَجِرْنِي مِنَ النَّارِ',
      bangla: 'হে আল্লাহ! আমাকে জাহান্নামের আগুন থেকে মুক্তি দাও।',
      pronunciation: 'আল্লাহুম্মা আজিরনি মিনান নার।'
  }
];

const Duas = () => {
  return (
    <div className="p-4 space-y-4 animate-fade-in pb-20">
      {DUAS.map((dua, index) => (
        <div key={index} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
            <h3 className="text-lg font-bold text-emerald-700 mb-3">{dua.title}</h3>
            <div className="bg-emerald-50 p-4 rounded-xl mb-3">
                <p className="text-right text-xl font-arabic leading-loose text-slate-800 font-medium">{dua.arabic}</p>
            </div>
            <div className="space-y-2">
                <p className="text-slate-600 text-sm italic">{dua.pronunciation}</p>
                <p className="text-slate-800">{dua.bangla}</p>
            </div>
        </div>
      ))}
    </div>
  );
};

export default Duas;
