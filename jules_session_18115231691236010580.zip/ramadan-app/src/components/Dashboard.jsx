import React, { useState, useEffect } from 'react';
import { getPrayerTimes, PRAYER_NAMES_BN } from '../utils/prayerTimes';
import { Sunrise, Sunset, MapPin } from 'lucide-react';
import { format } from 'date-fns';
import { bn } from 'date-fns/locale';

const toBengaliNumerals = (str) => {
  const bengaliNumerals = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  return str.replace(/\d/g, (d) => bengaliNumerals[d]);
};

const Dashboard = () => {
  const [times, setTimes] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const t = getPrayerTimes();
    setTimes(t);

    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  if (!times) return <div className="p-4 text-center">লোড হচ্ছে...</div>;

  const todayDate = toBengaliNumerals(format(new Date(), 'eeee, d MMMM yyyy', { locale: bn }));

  return (
    <div className="p-4 space-y-6 animate-fade-in">
      {/* Date & Location */}
      <div className="text-center space-y-1">
        <h2 className="text-xl font-bold text-slate-800">{todayDate}</h2>
        <div className="flex items-center justify-center text-slate-500 gap-1 text-sm">
          <MapPin size={16} />
          <span>ঢাকা, বাংলাদেশ</span>
        </div>
      </div>

      {/* Main Highlights: Sehri & Iftar */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 flex flex-col items-center justify-center relative overflow-hidden">
            <div className="absolute top-0 right-0 p-2 opacity-10">
                <Sunrise size={64} />
            </div>
            <span className="text-slate-500 text-sm font-medium mb-1">সেহরি শেষ</span>
            <span className="text-3xl font-bold text-emerald-600">{times.formattedBn.sehri}</span>
        </div>
        
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 flex flex-col items-center justify-center relative overflow-hidden">
            <div className="absolute top-0 right-0 p-2 opacity-10">
                <Sunset size={64} />
            </div>
            <span className="text-slate-500 text-sm font-medium mb-1">ইফতার</span>
            <span className="text-3xl font-bold text-orange-600">{times.formattedBn.iftar}</span>
        </div>
      </div>

      {/* All Prayer Times List */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="bg-emerald-50 p-3 border-b border-emerald-100">
            <h3 className="font-semibold text-emerald-800 text-center">আজকের নামাজের সময়সূচি</h3>
        </div>
        <div className="divide-y divide-slate-100">
            {['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'].map((key) => (
                <div key={key} className="flex justify-between items-center p-4 hover:bg-slate-50 transition-colors">
                    <span className="font-medium text-slate-700">{PRAYER_NAMES_BN[key]}</span>
                    <span className="font-bold text-slate-900 bg-slate-100 px-3 py-1 rounded-full text-sm">
                        {times.formattedBn[key]}
                    </span>
                </div>
            ))}
        </div>
      </div>
      
      {/* Sunrise note */}
      <div className="text-center text-xs text-slate-400">
        সূর্যোদয়: {times.formattedBn.sunrise}
      </div>
    </div>
  );
};

export default Dashboard;
